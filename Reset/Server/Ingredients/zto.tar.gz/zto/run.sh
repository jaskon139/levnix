sudo /home/tc/zto/zerotier-one -d /home/tc/zto
sudo ifconfig ztks5zqxjd 10.241.164.127 netmask 255.255.0.0
cd ..
tar xvf kcptun-linux-386-20180316.tar.gz
chmod +x client_linux_386
unzip zto/v2ray-linux-32.zip
cd zto
./startbs9940_2346.sh
