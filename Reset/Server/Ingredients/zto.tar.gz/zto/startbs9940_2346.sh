## define end value ##
END=1
#~/kcptun2/googledocker/startbs4480.sh &
## print date five times ##
x=$END
while [ $x -gt 0 ];
do
  date
  curl https://nowdocker-eehbwumtsj.now.sh
  ../client_linux_386 -r "10.241.54.180:9999" -l ":7878" -mode fast2 &
  ../v2ray-v3.31-linux-32//v2ray -config ./config.json &
  sleep 15m
  x=$(($x+1))
done
